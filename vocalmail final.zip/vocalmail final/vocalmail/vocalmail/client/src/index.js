
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './components/App';
import './styles.css';
// Initialize EmailJS with public key
import emailjs from 'emailjs-com';
emailjs.init(process.env.REACT_APP_EMAILJS_PUBLIC_KEY);

// Setup React Router and Google OAuth
import { BrowserRouter } from 'react-router-dom';
import { GoogleOAuthProvider } from '@react-oauth/google';
// Render the root of the React app
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <GoogleOAuthProvider clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </GoogleOAuthProvider>
);
