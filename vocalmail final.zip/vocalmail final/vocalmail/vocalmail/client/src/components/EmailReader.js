// client/src/components/EmailReader.js
import React, { useEffect, useState } from 'react';

export default function EmailReader({ email, token, onClose }) {
  const [status, setStatus] = useState('');

  // Use browser TTS
  const speakText = text => {
    return new Promise(resolve => {
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = 'en-US';
      utter.rate = 1;
      utter.onend = resolve;
      window.speechSynthesis.speak(utter);
      setStatus('Speaking…');
    });
  };

  useEffect(() => {
    (async () => {
      await speakText(`Email from ${email.from}, subject: ${email.subject}`);
      await speakText(email.body);
      setStatus('Done speaking');
    })();
    // cleanup
    return () => window.speechSynthesis.cancel();
  }, []);

  return (
    <div className="email-reader">
      <h2>Read Email</h2>
      <p><strong>From:</strong> {email.from}</p>
      <p><strong>Subject:</strong> {email.subject}</p>
      <div className="email-body">{email.body}</div>
      <div className="status-message">{status}</div>
      <button onClick={onClose}>Close</button>
    </div>
  );
}
