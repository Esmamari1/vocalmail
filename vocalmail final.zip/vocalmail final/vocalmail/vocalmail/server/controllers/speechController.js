const { Readable } = require('stream');
const speech = require('@google-cloud/speech');
const textToSpeech = require('@google-cloud/text-to-speech');
const googleConfig = require('../config/googleConfig');
//initalise test to speech
const speechClient = new speech.SpeechClient({ credentials: googleConfig.credentials });
const ttsClient = new textToSpeech.TextToSpeechClient({ credentials: googleConfig.credentials });

const convertSpeechToText = async (audioBuffer) => {
  try {
    const audio = { content: audioBuffer.toString('base64') };
    const config = googleConfig.speechToText;

    const request = { audio, config };
    const [response] = await speechClient.recognize(request);
    const transcription = response.results
      .map(result => result.alternatives[0].transcript)
      .join('\n');

    return transcription;
  } catch (error) {
    console.error('Speech to text error:', error);
    throw new Error('Failed to convert speech to text');
  }
};
//Converts text to speech audio using Google Text-to-Speech API
const convertTextToSpeech = async (text) => {
  try {
    const request = {
      input: { text },
      voice: googleConfig.textToSpeech,
      audioConfig: { audioEncoding: 'MP3' }
    };

    const [response] = await ttsClient.synthesizeSpeech(request);
    return response.audioContent;
  } catch (error) {
    console.error('Text to speech error:', error);
    throw new Error('Failed to convert text to speech');
  }
};

module.exports = { convertSpeechToText, convertTextToSpeech };
