import React, { useState, useEffect } from 'react';
import EmailComposer from './EmailComposer';
import EmailReader   from './EmailReader';

const API = process.env.REACT_APP_API_BASE_URL;

export default function MainPage({ token }) {
  const [mode, setMode]          = useState('inbox');
  const [emails, setEmails]      = useState([]);        // for inbox/junk/etc
  const [sentEmails, setSentEmails] = useState([]);     // your client‐side Sent folder
  const [sel, setSel]            = useState(null);

  // Fetch messages for inbox/junk/deleted/archive when mode changes:
  useEffect(() => {
    if (mode === 'compose' || mode === 'read' || mode === 'sent') return;
    fetch(`${API}/emails?folder=${mode}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(r => r.json())
      .then(data => {
        setEmails(data);
        setSel(null);
      })
      .catch(err => console.error(err));
  }, [mode, token]);

  return (
    <div className="main-page">
      <nav className="mailbox-nav">
        {['inbox','sent','deleted','junk','archive','compose'].map(folder => (
          <button
            key={folder}
            onClick={() => setMode(folder)}
            className={mode === folder ? 'active' : ''}
          >
            {folder.charAt(0).toUpperCase() + folder.slice(1)}
          </button>
        ))}
      </nav>

      {mode === 'compose' && (
        <EmailComposer
          onClose={() => setMode('inbox')}
          onSent={msg => {
            // Prepend the sent message into our in‐memory Sent list,
            // then switch to the Sent view.
            setSentEmails([msg, ...sentEmails]);
            setMode('sent');
          }}
        />
      )}

      {mode === 'sent' && (
        <ul className="email-list">
          {sentEmails.map((e, idx) => (
            <li key={idx}>
              <strong>To: {e.to}</strong> — {e.subject}
            </li>
          ))}
        </ul>
      )}

      {mode !== 'compose' && mode !== 'read' && mode !== 'sent' && (
        <ul className="email-list">
          {emails.map(e => (
            <li
              key={e.id}
              onClick={() => {
                setSel(e);
                setMode('read');
              }}
            >
              <strong>{e.from}</strong>: {e.subject}
            </li>
          ))}
        </ul>
      )}

      {mode === 'read' && sel && (
        <EmailReader email={sel} onBack={() => setMode('inbox')} />
      )}
    </div>
  );
}
