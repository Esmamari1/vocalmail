
// server/controllers/emailController.js
const nodemailer    = require('nodemailer');
const { gmailClient } = require('../config/googleConfig');

//  SMTP Transport for sending 
const transporter = nodemailer.createTransport({
  host:   process.env.SMTP_HOST,
  port:   Number(process.env.SMTP_PORT),
  secure: true,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

//  Send Email 
exports.sendEmail = async (_u, { to, subject, body }) => {
  const info = await transporter.sendMail({
    from:    process.env.SMTP_USER,
    to, subject,
    text:    body,
  });
  return info;
};

//  Helper: fetch message headers by Gmail label 
async function fetchHeadersByLabel(labelIds) {
  // list up to 20 message
  const listRes = await gmailClient.users.messages.list({
    userId:   'me',
    labelIds,
    maxResults: 20,
  });
  const messages = listRes.data.messages || [];
  // fetch each message’s headers
  const detailed = await Promise.all(
    messages.map(m =>
      gmailClient.users.messages.get({
        userId: 'me',
        id:     m.id,
        format: 'metadata',
        metadataHeaders: ['From','To','Subject','Date']
      })
    )
  );
  // map to the shape UI expects
  return detailed.map(m => {
    const hdrs = m.data.payload.headers.reduce((acc, h) => {
      acc[h.name.toLowerCase()] = h.value;
      return acc;
    }, {});
    return {
      id:      m.data.id,
      from:    hdrs.from || hdrs.to,    // use To: as from for sent
      subject: hdrs.subject || '',
      date:    hdrs.date    || '',
    };
  });
}

// Get full body text for a single message 
exports.getEmailById = async id => {
  const res = await gmailClient.users.messages.get({
    userId: 'me',
    id,
    format: 'full',
  });
  // find the text/plain part
  const part = (res.data.payload.parts || [])
    .find(p => p.mimeType === 'text/plain');
  const data = (part?.body?.data || res.data.payload.body.data || '')
    .replace(/-/g, '+').replace(/_/g, '/'); // base64url → base64
  const buff = Buffer.from(data, 'base64');
  return buff.toString('utf8');
};

//  Get a list of messages for any folder 
exports.getEmailsByFolder = async folder => {
  switch (folder) {
    case 'inbox':
      return fetchHeadersByLabel(['INBOX']);
    case 'sent':
      return fetchHeadersByLabel(['SENT']);
    case 'deleted':
      return fetchHeadersByLabel(['TRASH']);
    case 'junk':
      return fetchHeadersByLabel(['SPAM']);
    case 'archive':
      
      return fetchHeadersByLabel([]);
    default:
      throw new Error(`Unknown folder: ${folder}`);
  }
};
