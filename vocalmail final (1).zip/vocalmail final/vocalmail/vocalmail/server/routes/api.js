
// module.exports = router;
const express = require('express');
const {
  sendEmail,
  getEmailsByFolder,
  getEmailById
} = require('../controllers/emailController');

const router = express.Router();

// POST /emails/send … your current sendEmail handler

// GET /emails folder=inbox|sent|deleted|
router.get('/emails', async (req, res) => {
  try {
    const list = await getEmailsByFolder(req.query.folder || 'inbox');
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /emails/:id → gives back { body: "..." }
router.get('/emails/:id', async (req, res) => {
  try {
    const body = await getEmailById(req.params.id);
    res.json({ body });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
