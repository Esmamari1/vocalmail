
require('dotenv').config({ path: __dirname + '/.env' });

// Display loaded SMTP configuration (hide actual password)
console.log('→ SMTP_HOST=', process.env.SMTP_HOST);
console.log('→ SMTP_PORT=', process.env.SMTP_PORT);
console.log('→ SMTP_USER=', process.env.SMTP_USER);
console.log('→ SMTP_PASS=', process.env.SMTP_PASS ? '***present***' : '***missing***');

const express = require('express');
const cors = require('cors');
const path = require('path');
const apiRoutes = require('./routes/api');

const app = express();
const PORT = process.env.PORT || 5001;

app.use(cors());
app.use(express.json());
app.use('/api', apiRoutes);

// In production, serve static files from the React build folder.
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/build')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
  });
}
//Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
