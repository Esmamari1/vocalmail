
// server/config/googleConfig.js
const { google } = require('googleapis');
require('dotenv').config();
//// Load Google APIs and environment variables
const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET
);
oauth2Client.setCredentials({
  refresh_token: process.env.GOOGLE_REFRESH_TOKEN
});
// Use the refresh token to get new access tokens automatically.
const gmailClient = google.gmail({ version: 'v1', auth: oauth2Client });
module.exports = { gmailClient };
