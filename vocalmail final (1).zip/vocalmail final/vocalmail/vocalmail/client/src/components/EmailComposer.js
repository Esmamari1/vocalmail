// client/src/components/EmailComposer.js
import React, { useState, useRef, useEffect } from 'react';
import emailjs from 'emailjs-com';
import './EmailComposer.css'; 

const SERVICE_ID  = process.env.REACT_APP_EMAILJS_SERVICE_ID;
const TEMPLATE_ID = process.env.REACT_APP_EMAILJS_TEMPLATE_ID;

export default function EmailComposer({ onClose, onSent }) {
  const [to, setTo]           = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody]       = useState('');
  const [status, setStatus]   = useState('');
  const [listeningFor, setListeningFor] = useState(null);

  const recognitionRef = useRef(null);

  // begin speech recognition for specific area
  const startListening = field => {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) {
      setStatus('SpeechRecognition not supported');
      return;
    }

    // stop any existing recorder
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }

    const rec = new SpeechRec();
    rec.continuous      = true;            // keep capturing until stopped
    rec.interimResults  = false;           // only final results
    rec.lang            = 'en-US';         // adjust as needed

    rec.onstart = () => {
      setListeningFor(field);
      setStatus(`Listening for ${field}…`);
    };

    rec.onresult = event => {
      // Grab the most recent result
      const last = event.results[event.results.length - 1];
      const text = last[0].transcript.trim();

      if (field === 'to')       setTo(prev => prev + ' ' + text);
      if (field === 'subject')  setSubject(prev => prev + ' ' + text);
      if (field === 'body')     setBody(prev => prev + ' ' + text);
    };

    rec.onerror = () => {
      setStatus(`Error during ${field} recognition`);
      stopListening();
    };

    rec.onend = () => {
      setListeningFor(null);
      setStatus(`Stopped listening`);
    };

    rec.start();
    recognitionRef.current = rec;
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    setListeningFor(null);
  };

  // clean up on unmount
  useEffect(() => {
    return () => {
      stopListening();
    };
  }, []);

  const sendEmail = async () => {
    if (!to || !subject || !body) {
      setStatus('Please fill all fields before sending');
      return;
    }

    setStatus('Sending email…');
    try {
      const res = await emailjs.send(
        SERVICE_ID,
        TEMPLATE_ID,
        {
          to_email: to,
          subject,
          message: body,
          from_email: to,
          from_name: to,
          name: to,
        }
      );
      setStatus('✅ Email sent!');
      onSent && onSent({ to, subject, body });
      setTimeout(onClose, 1200);
    } catch (err) {
      console.error(err);
      setStatus('❌ Failed to send');
    }
  };

  return (
    <div className="email-composer">
      <h2>Compose Email</h2>

      {/** TO field **/}
      <div className="field">
        <label>To:</label>
        <input
          type="email"
          value={to}
          onChange={e => setTo(e.target.value)}
          placeholder="recipient@example.com"
        />
        <button
          onClick={() =>
            listeningFor === 'to' ? stopListening() : startListening('to')
          }
        >
          {listeningFor === 'to' ? '⏹️ Stop' : '🎤 Record'}
        </button>
      </div>

      {/** SUBJECT field **/}
      <div className="field">
        <label>Subject:</label>
        <input
          value={subject}
          onChange={e => setSubject(e.target.value)}
          placeholder="Subject line"
        />
        <button
          onClick={() =>
            listeningFor === 'subject' ? stopListening() : startListening('subject')
          }
        >
          {listeningFor === 'subject' ? '⏹️ Stop' : '🎤 Record'}
        </button>
      </div>

      {/** BODY field **/}
      <div className="field">
        <label>Body:</label>
        <textarea
          value={body}
          onChange={e => setBody(e.target.value)}
          placeholder="Type or speak your message here…"
          rows={6}
        />
        <button
          onClick={() =>
            listeningFor === 'body' ? stopListening() : startListening('body')
          }
        >
          {listeningFor === 'body' ? '⏹️ Stop' : '🎤 Record'}
        </button>
      </div>

      <div className="status">{status}</div>

      <div className="actions">
        <button className="send" onClick={sendEmail}>Send Email</button>
        <button className="cancel" onClick={onClose}>Cancel</button>
      </div>
    </div>
  );
}
