
// src/components/App.js
import React, { useState } from 'react';
import { Routes, Route, NavLink, Navigate } from 'react-router-dom';

import LoginPage     from './LoginPage';
import InboxPage     from './InboxPage';
import SentPage      from './SentPage';       // put the SentPage import back in
import EmailComposer from './EmailComposer';

export default function App() {
  const [token, setToken] = useState(null);
  const [sentEmails, setSentEmails] = useState([]);

  // 1 Stay on the login screen until we get a token.
  if (!token) {
    return <LoginPage setAccessToken={setToken} />;
  }

  // 2) Once you've logged in, show the nav and routes.
  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <nav style={{
        width:       200,
        padding:     20,
        background:  '#111',
        color:       '#ccc',
        display:     'flex',
        flexDirection:'column',
        gap:         10
      }}>
        <h1 style={{ color: 'white', fontSize: 24 }}>VocalMail</h1>

        <NavLink to="/inbox"   style={linkStyle}>Inbox</NavLink>
        <NavLink to="/sent"    style={linkStyle}>Sent</NavLink>
        <NavLink to="/deleted" style={linkStyle}>Deleted</NavLink>
        <NavLink to="/compose" style={linkStyle}>Compose</NavLink>
      </nav>

      <main style={{ flex: 1, overflow: 'auto' }}>
        <Routes>
          {/* redirect root → inbox */}
          <Route path="/" element={<Navigate to="/inbox" replace />} />

          {/*  inbox view */}
          <Route
            path="/inbox"
            element={<InboxPage token={token} folder="INBOX" />}
          />

          {/* sent view */}
          <Route
            path="/sent"
            element={<SentPage sentEmails={sentEmails} />}
          />

          {/*  deleted view */}
          <Route
            path="/deleted"
            element={<InboxPage token={token} folder="TRASH" />}
          />

          {/* composer view; onSent adds to sentEmails */}
          <Route
            path="/compose"
            element={
              <EmailComposer
                onSent={emailObj => setSentEmails(es => [emailObj, ...es])}
                onClose={() => {}}
              />
            }
          />

          {/* catch-all 404 */}
          <Route
            path="*"
            element={<h2 style={{ padding: 20 }}>404 — Not Found</h2>}
          />
        </Routes>
      </main>
    </div>
  );
}

const linkStyle = ({ isActive }) => ({
  padding:      '8px',
  borderRadius: 4,
  background:   isActive ? '#333' : 'transparent',
  color:        isActive ? '#fff' : '#888'
});
