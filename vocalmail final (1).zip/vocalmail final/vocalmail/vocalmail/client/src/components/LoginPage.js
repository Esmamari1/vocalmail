
// src/components/LoginPage.js
import React from 'react';
import { useGoogleLogin } from '@react-oauth/google';

export default function LoginPage({ setAccessToken }) {
  const login = useGoogleLogin({
    flow: 'implicit',  // get an access_token directly
    scope:
      'https://www.googleapis.com/auth/gmail.readonly ' +
      'https://www.googleapis.com/auth/gmail.send ' +
      'https://www.googleapis.com/auth/gmail.modify',
    onSuccess: resp => {
      console.log('Got token:', resp.access_token);
      setAccessToken(resp.access_token);
    },
    onError: err => {
      console.error('Login Failed:', err);
      alert('Google login failed');
    },
  });

  return (
    <div style={{
      height: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'column',
      background: '#111',
      color: '#fff'
    }}>
      <h1>VocalMail</h1>
      <button
        onClick={() => login()}
        style={{
          padding: '0.75rem 1.5rem',
          fontSize: '1.1rem',
          background: '#fbbc05',
          border: 'none',
          borderRadius: 4,
          cursor: 'pointer'
        }}
      >
        Sign in with Google
      </button>
    </div>
  );
}
