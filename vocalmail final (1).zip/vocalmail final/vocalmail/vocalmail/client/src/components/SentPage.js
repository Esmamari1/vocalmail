//src/components/SentPage.js
import React from 'react';

export default function SentPage({ sentEmails }) {
  if (sentEmails.length === 0) {
    return <p style={{ padding: 20 }}>No emails sent yet.</p>;
  }
  return (
    <div style={{ padding: 20 }}>
      <h2>Sent Messages</h2>
      {sentEmails.map((e, i) => (
        <div key={i} style={{
          background: '#222',
          color: '#fff',
          padding: 12,
          margin: '12px 0',
          borderRadius: 6,
        }}>
          <div><strong>To:</strong> {e.to}</div>
          <div><strong>Subject:</strong> {e.subject}</div>
          <button
            style={{
              marginTop: 8,
              background: '#4caf50',
              border: 'none',
              color: 'white',
              padding: '6px 12px',
              borderRadius: 4,
              cursor: 'pointer',
            }}
            onClick={() => {
              const utter = new SpeechSynthesisUtterance(
                `Sent to ${e.to}. Subject: ${e.subject}. ${e.body}`
              );
              utter.lang = 'en-US';
              window.speechSynthesis.speak(utter);  // reads sent messages out loud
            }}
          >
            🔊 Read Aloud
          </button>
        </div>
      ))}
    </div>
  );
}
