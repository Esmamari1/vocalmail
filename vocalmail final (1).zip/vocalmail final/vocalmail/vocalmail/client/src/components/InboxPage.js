
// src/components/InboxPage.js
import React, { useEffect, useState } from 'react';

export default function InboxPage({ token, folder = 'INBOX' }) {
  const [emails, setEmails]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState('');

  // decode text/plain or go back
  function getBody(payload) {
    if (payload.parts) {
      const part = payload.parts.find(p => p.mimeType === 'text/plain');
      if (part?.body?.data) {
        const b64 = part.body.data.replace(/-/g, '+').replace(/_/g, '/');
        return atob(b64);
      }
    }
    return payload.snippet || '';
  }

  useEffect(() => {
    setLoading(true);
    setError('');
    fetch(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=10&labelIds=${folder}`,
      { headers: { Authorization: `Bearer ${token}` } }
    )
      .then(res => {
        if (!res.ok) throw new Error(res.statusText);
        return res.json();
      })
      .then(async data => {
        if (!data.messages) {
          setEmails([]);
          return;
        }
        const msgs = await Promise.all(
          data.messages.map(m =>
            fetch(
              `https://gmail.googleapis.com/gmail/v1/users/me/messages/${m.id}?format=full`,
              { headers: { Authorization: `Bearer ${token}` } }
            ).then(r => r.json())
          )
        );
        setEmails(
          msgs.map(msg => {
            const hdrs = msg.payload.headers.reduce((acc, h) => {
              acc[h.name.toLowerCase()] = h.value;
              return acc;
            }, {});
            return {
              id:      msg.id,
              from:    hdrs.from || '',
              subject: hdrs.subject || '',
              date:    hdrs.date || '',
              body:    getBody(msg.payload),
            };
          })
        );
      })
      .catch(err => {
        console.error(err);
        setError('Failed to load inbox');
      })
      .finally(() => setLoading(false));
  }, [token, folder]);

  // delete garbage through the Gmail API and update the local state
  const deleteEmail = async (id) => {
    setError('');
    try {
      const resp = await fetch(
        `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}/trash`,
        {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (!resp.ok) {
        const errJson = await resp.json();
        console.error('Trash error:', errJson);
        setError(errJson.error?.message || 'Error deleting message');
        return;
      }
      // remove from UI
      setEmails(es => es.filter(e => e.id !== id));
    } catch (err) {
      console.error('Delete exception:', err);
      setError('Network error deleting message');
    }
  };

  if (loading) return <p style={{ padding:20 }}>Loading inbox…</p>;
  if (error)   return <p style={{ padding:20, color:'tomato' }}>{error}</p>;
  if (!emails.length)
    return <p style={{ padding:20 }}>Your inbox is empty.</p>;

  return (
    <div style={{ padding:20 }}>
      <h2>Inbox</h2>
      {emails.map(e => (
        <div key={e.id} style={{
          background: '#222',
          color:      '#fff',
          padding:     12,
          margin:     '12px 0',
          borderRadius: 6,
        }}>
          <div><strong>From:</strong> {e.from}</div>
          <div><strong>Subject:</strong> {e.subject}</div>
          <div style={{ fontSize:12, color:'#888' }}>{e.date}</div>
          <div style={{ marginTop:8, display:'flex', gap:8 }}>
            <button
              style={{
                background: '#4caf50',
                border:     'none',
                color:      'white',
                padding:    '6px 12px',
                borderRadius: 4,
                cursor:     'pointer',
              }}
              onClick={() => {
                const read = new SpeechSynthesisUtterance(
                  `Email from ${e.from}. Subject: ${e.subject}. ${e.body}`
                );
                window.speechSynthesis.speak(read);
              }}
            >
              🔊 Read Aloud
            </button>
            <button
              style={{
                background: '#d32f2f',
                border:     'none',
                color:      'white',
                padding:    '6px 12px',
                borderRadius: 4,
                cursor:     'pointer',
              }}
              onClick={() => deleteEmail(e.id)}
            >
              🗑️ Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
