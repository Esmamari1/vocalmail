// client/src/utils/speechUtils.js
//// Begin recording from mic, returns recorder
export const startRecording = async (setIsRecording, onStop) => {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const recorder = new MediaRecorder(stream);
  const chunks = [];
  recorder.ondataavailable = e => chunks.push(e.data);
  recorder.onstop = () => {
    const blob = new Blob(chunks, { type: 'audio/wav' });
    onStop(blob);
  };
  recorder.start();
  setIsRecording(true);
  return recorder;
};
// Stop recorder and stop mic
export const stopRecording = (recorder, setIsRecording) => {
  recorder.stop();
  recorder.stream.getTracks().forEach(t => t.stop());
  setIsRecording(false);
};
// Play MP3 data from ArrayBuffer
export const playAudio = async arrayBuffer => {
  const blob = new Blob([arrayBuffer], { type: 'audio/mp3' });
  const url  = URL.createObjectURL(blob);
  const audio = new Audio(url);
  await audio.play();
  audio.onended = () => URL.revokeObjectURL(url);
  return audio;
};
